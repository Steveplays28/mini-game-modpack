// Vertex GL version
#version 330 compatibility

#define GBUFFERS
#define BASIC
#define VERTEX

#include "/lib/settings.glsl"
#include "/lib/utility/common.glsl"

#include "world.glsl"
#include "/main/gbuffers/gbuffers_basic.glsl"